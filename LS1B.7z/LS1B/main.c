//�༶�˵�����

#include <stdio.h>

#include "ls1b.h"
#include "mips.h"
#include "lkdGui.h"
#include "user_rtc_drv.h"
#include "hmc5883l_drv.h"
#include "motor_drv.h"
#include "user_gauge_drv.h"
#include "fan_resistance_control_drv.h"

extern  lkdFont defaultFont;
//-------------------------------------------------------------------------------------------------
// BSP
//-------------------------------------------------------------------------------------------------

#include "bsp.h"
#include "ls1x_fb.h"


char LCD_display_mode[] = LCD_800x480;

static unsigned char key_value=0;

#include "uart.h"


int main(void)
{
    printk("\r\nmain() function.\r\n");

    ls1x_drv_init();            		/* Initialize device drivers */

    install_3th_libraries();      		/* Install 3th libraies */

    BEEP_Init();

    KEY_Init();//������ʼ��

    LED_IO_Config();//LED��ʼ��

    SMG_Init();

    user_rtc_init();

    Motor_GPIO_Config();
    Motor_Interrupt_Init();//��ʼ���ⲿ�ж�
    fan_resistance_io_Config();
    Fan_Control(100);//
    UART4_Config_Init();//����ģ�鴮�ڳ�ʼ��
    defaultFontInit();/* �ֿ��ʼ�� */
    GuiUpdateDisplayAll();/* ������Ļ-���� */

    userAppInit();

    for (;;)
    {
        userAppMain();

        //ѭ�����ô��ڴ���
        GuiWinDisplay();
        MenukeyResult();

    }

}

/*
 * @@ End
 */
