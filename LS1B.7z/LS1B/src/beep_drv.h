/*
 * beep.h
 *
 * created: 2022/2/25
 *  author: 
 */

#ifndef _BEEP_H
#define _BEEP_H

#define BEEP 46
void BEEP_Init(void);
void BEEP_On(void);
void BEEP_Off(void);
#endif // _BEEP_H

