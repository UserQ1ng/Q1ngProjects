/*
 * bkrc_voice.h
 *
 * created: 2022/2/28
 *  author:
 */

#ifndef _BKRC_VOICE_H
#define _BKRC_VOICE_H

extern unsigned char start_voice_dis[5];


unsigned char Voice_Drive(void);

unsigned char BKRC_Voice_Extern(void)	;	// ����ʶ��;

#endif // _BKRC_VOICE_H


