/*
 * led_drv.c
 *
 * created: 2022/6/8
 *  author:
 */
#include "bsp.h"
#include "ls1b_gpio.h"
#include "led_drv.h"



//LED��ʼ��
void LED_IO_Config(void)
{
    //����GPIOΪ���״̬
    gpio_enable(LED3,DIR_OUT);
    gpio_enable(LED2,DIR_OUT);
    gpio_enable(LED1,DIR_OUT);

    gpio_write(LED3,OFF);//�ر�LED
    gpio_write(LED2,OFF);//�ر�LED
    gpio_write(LED1,OFF);//�ر�LED


}

//LED���Ժ���
void LED_Test(void)
{
    if(gpio_read(57) == 1)
    {
        gpio_write(LED1,ON);//����LED
        delay_ms(1000);
        gpio_write(LED1,OFF);
        gpio_write(LED2,ON);//����LED
        delay_ms(1000);
        gpio_write(LED2,OFF);
        gpio_write(LED3,ON);
        delay_ms(1000);
        gpio_write(LED3,OFF);
        gpio_write(LED1,ON);//����LED
        delay_ms(1000);
        gpio_write(LED1,OFF);
        gpio_write(LED2,ON);//����LED
        delay_ms(1000);
        gpio_write(LED2,OFF);
        gpio_write(LED3,ON);
        delay_ms(1000);
        gpio_write(LED3,OFF);
        gpio_write(LED1,ON);//����LED
        delay_ms(1000);
        gpio_write(LED1,OFF);
        gpio_write(LED2,ON);//����LED
        delay_ms(1000);
        gpio_write(LED2,OFF);
        gpio_write(LED3,ON);
        delay_ms(1000);
        gpio_write(LED3,OFF);
    }

}
//����ָ��LED����
void LED_On(unsigned char led_num)
{

    gpio_write(led_num,ON);

}
//�ر�ָ��LED����
void LED_Off(unsigned char led_num)
{
    gpio_write(led_num,OFF);

}
//�ر�����LED����
void LED_All_Off(void)
{
    gpio_write(LED3,OFF);//�ر�LED
    gpio_write(LED2,OFF);//�ر�LED
    gpio_write(LED1,OFF);//�ر�LED
}

