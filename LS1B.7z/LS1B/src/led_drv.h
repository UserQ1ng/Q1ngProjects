/*
 * led_drv.h
 *
 * created: 2022/6/8
 *  author: 
 */

#ifndef _LED_DRV_H
#define _LED_DRV_H

#define LED1 34
#define LED2 37
#define LED3 35

#define ON  1
#define OFF 0

 void LED_IO_Config(void);
  void LED_Test(void);
void LED_On(unsigned char led_num);
void LED_Off(unsigned char led_num);
void LED_All_Off(void);
#endif // _LED_DRV_H

