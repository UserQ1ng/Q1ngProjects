/*
 * keyDriverPort.c
 *
 * created: 2022/7/13
 *  author:
 */
/**
  * @file   keyDriver.c
  * @author  guoweilkd
  * @version V1.1.0
  * @date    2018/05/16
  * @brief  ������������
  */

#include "keyDriverPort.h"
#include "stdint.h"
#include "key_drv.h"
#include "ls1b_gpio.h"
/* ������Ϣ */
struct KeyInfo keyInfo;
/* �����仯�����ص� */
void (* KeyChangeDealWith)(uint8_t keyNum,uint8_t state);

/* �˵�����ö�� */
enum MenuKeyIs menuKeyState;

void MenukeyResult(uint8_t keyNum,uint8_t state);


/**
  *@brief  �˵���������
  *@param  ����ֵ
  *@param  ����״̬
  *@retval None
  */
void MenukeyResult(uint8_t keyNum,uint8_t state)
{
    uint8_t key_value=0;
     key_value=KEY_Scan();
    
    if(key_value == 0)
    {
        return;
    }
    switch(key_value)
    {
        case MENUY_UP:
            menuKeyState = MKEY_UP;
            printk("up_press\r\n");
            break;
        case MENUKEY_DOWN:
            menuKeyState = MKEY_DOWN;
               printk("down_press\r\n");
            break;
        case MENUKEY_LEFT:
            menuKeyState = MKEY_LEFT;
               printk("left_press\r\n");
            break;
        case MENUKEY_RIGHT:
            menuKeyState = MKEY_RIGHT;
               printk("right_press\r\n");
            break;
        case MENUKEY_OK:
            menuKeyState = MKEY_OK;
            printk("ok_press\r\n");
            break;
        case MENUKEY_CANCEL:
            menuKeyState = MKEY_CANCEL;
            printk("cancel_press\r\n");
            break;
        default:
            break;
    }
}

/**
  *@brief  ��ȡ�˵�״̬
  *@param  None
  *@retval �˵�״̬
  */
enum MenuKeyIs GetMenuKeyState(void)
{
    return menuKeyState;
}

/**
  *@brief  ����˵�״̬
  *@param  None
  *@retval None
  */
void SetMenuKeyIsNoKey(void)
{
    menuKeyState = MKEY_NO;
}

/* END */


