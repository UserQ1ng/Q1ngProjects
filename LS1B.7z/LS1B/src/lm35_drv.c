/*
 * lm35_drv.c
 *
 * created: 2022/7/14
 *  author: 
 */

#include <stdio.h>
#include "ls1b.h"
#include "stdint.h"
#include "ls1x_i2c_bus.h"
#include "i2c/ads1015.h"
#include "lm35_drv.h"
float lm35_get_temp(void)
{
        uint16_t adc2=0;
        float temp=0;
        adc2 = get_ads1015_adc(busI2C0, ADS1015_REG_CONFIG_MUX_SINGLE_2);
        temp = 4.096*2*adc2/4096;//�ɼ���ѹ��ת����ʽ
        //printf("adc:%f v\r\n",temp);
        //printf("temp %.02f�� \r\n",temp*100);
        return temp*100;
}
