/*
 * lm35_drv.h
 *
 * created: 2022/7/14
 *  author: 
 */

#ifndef _LM35_DRV_H
#define _LM35_DRV_H
float lm35_get_temp(void);

#endif // _LM35_DRV_H

