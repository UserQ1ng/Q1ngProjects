/*
 * lwip_test.c
 *
 * created: 2021/6/27
 *  author:
 */

#include "lwip_test.h"
#include <stdio.h>

#include "ls1b.h"
#include "mips.h"

//-------------------------------------------------------------------------------------------------
// BSP
//-------------------------------------------------------------------------------------------------

#include "bsp.h"

#if BSP_USE_LWMEM
#include "libc/lwmem.h"
#endif

#if defined(BSP_USE_GMAC0)
#include "lwip/tcp_impl.h"
#include "netif/etharp.h"
#include "lwip/ip_frag.h"
#include "lwip/netif.h"
#include "lwip/init.h"
extern struct netif *p_gmac0_netif;

extern void lwip_init(void);
extern void ls1x_initialize_lwip(unsigned char *lip, unsigned char *ip1);
extern void ethernetif_input(struct netif *netif);
#endif

#include "lwip_test.h"



static int tcpclient_count = 0;
void user_lwip_init(void)
{

    lwmem_initialize(0);
    unsigned char lip[4] = {192, 168, 1, 123};
    unsigned char rip[4] = {192, 168, 1, 111};

    lwip_init();                        // Initilaize the LwIP stack
    ls1x_initialize_lwip(lip, NULL);    // Initilaize the LwIP & GMAC0 glue
    tcp_client_initialize(lip, rip);
}
void tcp_client_test(char *send_pbuf)
{
    int rdbytes, wrbytes;
    ethernetif_input(p_gmac0_netif);
    tcp_tmr();          // lwip tcp �����̱�����ú��� tcp_tmr()

    char tmpbuf[TCP_CLIENT_BUFSIZE];
    /*
     * ����...
     */
    memset(tmpbuf, 0, TCP_CLIENT_BUFSIZE);
    sprintf(tmpbuf, "1B tick count=%i\r\n", get_clock_ticks());
    wrbytes = strlen(send_pbuf);
    wrbytes = tcpcli_send_data(send_pbuf, wrbytes);
    // printk("SEND: %s", tmpbuf);
    delay_ms(100);
    /*
     * ��һ�η��͵Ļش�
     */
    memset(tmpbuf, 0, TCP_CLIENT_BUFSIZE);
    rdbytes = tcpcli_recv_data(tmpbuf, TCP_CLIENT_BUFSIZE);
    if (rdbytes > 0)
    {
        tcpclient_count++;
        printk("SERVER REPLAY: %s\r\n", tmpbuf);
    }
}



