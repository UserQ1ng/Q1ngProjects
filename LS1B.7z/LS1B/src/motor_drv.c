/*
 * motor_drv.c
 *
 * created: 2022/7/15
 *  author:
 */
#include <stdio.h>

#include "ls1b.h"
#include "mips.h"
#include "bsp.h"
#include "motor_drv.h"
#include "ls1b_gpio.h"
#include "i2c/gp7101.h"
#include "ls1b_irq.h"
#include "stdint.h"

PID sPID1= {0};
PID *sptr1 = &sPID1;

void Motor_GPIO_Config(void)
{
    set_lcd_brightness(100);

}

/**************PID������ʼ��********************************/
void Inc_MOTOR_PIDInit(void)
{
    sptr1->LastError=0;            //Error[-1]
    sptr1->PrevError=0;            //Error[-2]
    sptr1->Proportion=P_MOTOR_DATA;      //�������� Proportional Const
    sptr1->Integral=I_MOTOR_DATA;        //���ֳ���  Integral Const
    sptr1->Derivative=D_MOTOR_DATA;      //΢�ֳ��� Derivative Const
    sptr1->SetPoint=100;           //�趨Ŀ��Desired Value
}

/********************λ��ʽ PID �������************************************/
unsigned int Loc_MOTOR_PIDCalc(int NextPoint)
{
    int iError,dError;
    iError = sptr1->SetPoint - NextPoint; //ƫ��
    sptr1->SumError += iError; //����
    dError = iError - sptr1->LastError; //΢��
    sptr1->LastError = iError;
    return(sptr1->Proportion * iError //������
           + sptr1->Integral * sptr1->SumError //������
           + sptr1->Derivative * dError); //΢����
}


//�ⲿ�жϷ�����
static unsigned int interrupt_flag=0;

static unsigned int motor_count=0;
static unsigned int last_motor_count=0;
static unsigned int result_motor_count=0;//����ʱ�����ϴ�ʱ���ֵ

static float result_motor_count2=0;//��������ת��
static unsigned int count3=0;
static void gpio_interrupt_isr(int vector, void * param)
{
    interrupt_flag=1;
    count3++;
    if(count3>73)
    {

        motor_count = get_clock_ticks();
        if(last_motor_count < motor_count)
        {
            result_motor_count= (motor_count - last_motor_count);
        }
        else
        {
            result_motor_count=  ((0xFFFFFFFF - last_motor_count)+motor_count);
        }
        result_motor_count2=60000/result_motor_count/3.0;
        last_motor_count=motor_count;
        count3=0;
    }

    return;
}

//�ⲿ�жϳ�ʼ��
void Motor_Interrupt_Init(void)
{
    //ls1x_install_gpio_isr(KEY_UP, INT_TRIG_EDGE_UP, gpio_interrupt_isr, 0);    /* �����ش��� */
    ls1x_install_gpio_isr(53, INT_TRIG_EDGE_DOWN, gpio_interrupt_isr, 0);  /* �½��ش��� */
    //ls1x_install_gpio_isr(53, INT_TRIG_LEVEL_HIGH, gpio_interrupt_isr, 0);  /* �ߵ�ƽ���� */
    //ls1x_install_gpio_isr(KEY_UP, INT_TRIG_LEVEL_LOW, gpio_interrupt_isr, 0);  /* �͵�ƽ���� */
    ls1x_enable_gpio_interrupt(53);    //ʹ���ж�

    return ;
}
extern volatile unsigned int Clock_driver_ticks;
static uint16_t motor_speed_check_time=0;
static uint16_t motor_speed_value=0;
uint16_t Motor_Speed_Check(void)
{

    uint16_t result_motor_speed=0;
    if(interrupt_flag)
    {
        interrupt_flag=0;
        result_motor_speed=(unsigned int)result_motor_count2;
        printf("motor2 %d\r\n",result_motor_speed);
    }
    else
    {
        result_motor_speed=0;
    }

    return result_motor_speed;
}


