/*
 * smg_drv.h
 *
 * created: 2022/7/8
 *  author: 
 */

#ifndef _SMG_DRV_H
#define _SMG_DRV_H




#include <stdio.h>

#include "ls1b.h"
#include "mips.h"
#include "ls1b_gpio.h"

//74HC595
#define  HC595_SI(val)  gpio_write(39,val)// GPIO_WriteBit(GPIOC, GPIO_Pin_6, (BitAction)val)
#define  HC595_RCK(val) gpio_write(48,val)// GPIO_WriteBit(GPIOC, GPIO_Pin_7, (BitAction)val)
#define  HC595_SCK(val) gpio_write(49,val)//GPIO_WriteBit(GPIOC, GPIO_Pin_8, (BitAction)val)

void SMG_Init(void);
void hc595_Test(unsigned short num);
void hc595_Test2(void);


#endif // _SMG_DRV_H

