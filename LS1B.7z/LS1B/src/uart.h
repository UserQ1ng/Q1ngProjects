/*
 * uart.h
 *
 * created: 2021/4/30
 *  author:
 */

#ifndef _UART_H
#define _UART_H

extern char buff[256];

#define UART4  devUART4

void UART4_Config_Init(void);
void UART4_Test(void);

#endif // _UART_H


