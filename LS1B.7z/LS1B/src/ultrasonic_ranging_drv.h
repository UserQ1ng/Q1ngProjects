/*
 * ultrasonic_ranging_drv.h
 *
 * created: 2022/7/15
 *  author: 
 */

#ifndef _ULTRASONIC_RANGING_DRV_H
#define _ULTRASONIC_RANGING_DRV_H


float Ultrasonic_Get_Dist(void);
float CS100A_Get_Dist(void);
void PWM2_Time_Init(void);


#endif // _ULTRASONIC_RANGING_DRV_H

