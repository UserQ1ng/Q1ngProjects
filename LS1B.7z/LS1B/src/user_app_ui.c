/*
 * user_app_ui.c
 *
 * created: 2022/7/13
 *  author:
 */
/**
  * @file   menutest.h
  * @author  guoweilkd
  * @version V0.0.0
  * @date    2018/06/30
  * @brief  �˵�ʹ��Demo
  */
#include "user_app_ui.h"
#include "keyDriverPort.h"
#include "lkdGui.h"
#include "user_rtc_drv.h"
#include "ls1x_rtc.h"
#include "ls1b_gpio.h"
#include "led_drv.h"
#include "pic_img.h"
#include "ns16550.h"
#include "lm35_drv.h"
#include "bh1750.h"
#include "hmc5883l_drv.h"
#include "ultrasonic_ranging_drv.h"
#include "fan_resistance_control_drv.h"
#include "motor_drv.h"
#include "lwip_test.h"
#include "ls1x_fb.h"
#include "user_gauge_drv.h"
/*�궨��*/
#define MAX_DATA_POINTS 100
/*ȫ�ֱ���*/


/* �˵����� */
enum MenuKeyIs keyStatus;
/* �˵���� */
lkdMenu HmiMenu;
/* �˵�ջ */
#define MENUSTACK_NUM 8
MenuStack userMenuStack[MENUSTACK_NUM];

/* �������� */
static void HomeFun(void *param);
static void MenuFun(void *param);
static void Win0Fun(void *param);
static void Win1Fun(void *param);
static void Win2Fun(void *param);
static void Win3Fun(void *param);
static void Win4_1Fun(void *param);
static void Win4_2Fun(void *param);
static void Win4_3Fun(void *param);
static void Win5Fun(void *param);
static void Win6Fun(void *param);
static void Win7Fun(void *param);
static void Win8Fun(void *param);

void Border(void);
void LightWave(unsigned char num);
void Wave(void);
//void ReClear(void);
//void Clear(void);
/* ���ڶ��� */
#define LKDWIN_WIN0_NAME "����1��GPIO������������"
#define LKDWIN_WIN1_NAME "����2��������ʾӦ�ÿ���"
#define LKDWIN_WIN2_NAME "����3��LCD��ʾ����ʾӦ�ÿ���"
#define LKDWIN_WIN3_NAME "����4��������������"
#define LKDWIN_WIN4_NAME "����5�����������ݲɼ�"
#define LKDWIN_WIN5_NAME "����6��GPIO��Χ�豸����"
#define LKDWIN_WIN6_NAME "����7��Ƕ��ʽϵͳUI���"
//
lkdWin homeWin = {5,5,470,790,"��о1B�ۺ���ʾ",HomeFun,NULL};/* ���洰�� */
lkdWin menuWin = {5,5,470,790,"�˵�����",MenuFun,NULL};/* �˵����� */
lkdWin win0 =    {20,200,440,300,LKDWIN_WIN0_NAME,Win0Fun,NULL};
lkdWin win1 =    {20,200,440,300,LKDWIN_WIN1_NAME,Win1Fun,NULL};
lkdWin win2 =    {20,200,440,300,LKDWIN_WIN2_NAME,Win2Fun,NULL};
lkdWin win3 =    {20,200,440,300,LKDWIN_WIN3_NAME,Win3Fun,NULL};
lkdWin win4_1 =  {20,200,440,300,"�¶ȴ�����",Win4_1Fun,NULL};
lkdWin win4_2 =  {20,200,440,300,"���նȴ�����",Win4_2Fun,NULL};
lkdWin win4_3 =  {20,200,440,300,"��������",Win4_3Fun,NULL};
lkdWin win5 =    {20,200,440,300,LKDWIN_WIN4_NAME,Win5Fun,NULL};
lkdWin win6 =    {20,200,440,300,LKDWIN_WIN5_NAME,Win6Fun,NULL};
lkdWin win7 =    {20,200,440,300,LKDWIN_WIN6_NAME,Win7Fun,NULL};
lkdWin win8 =    {20,200,440,300,"����ͼ���ڼ���...",Win8Fun,NULL};
/* �˵��ڵ㶨�� */
//lkdMenuNode Node33 = {33,"�����˵�4", NULL,   NULL,NULL};
//lkdMenuNode Node32 = {32,"�����˵�3", &Node33,NULL,NULL};
//lkdMenuNode Node31 = {31,"�����˵�2", &Node32,NULL,NULL};
//lkdMenuNode Node30 = {30,"�����˵�1", &Node31,NULL,&win2};

//lkdMenuNode Node29 = {29,"�����˵�17", NULL,    NULL,NULL};
//lkdMenuNode Node28 = {28,"�����˵�16", &Node29, NULL,NULL};
//lkdMenuNode Node27 = {27,"�����˵�15", &Node28, NULL,NULL};
//lkdMenuNode Node26 = {26,"�����˵�14", &Node27, NULL,NULL};
//lkdMenuNode Node25 = {25,"�����˵�13", &Node26, NULL,NULL};
//lkdMenuNode Node24 = {24,"�����˵�12", &Node25, NULL,NULL};
//lkdMenuNode Node23 = {23,"�����˵�11", &Node24, NULL,NULL};
//lkdMenuNode Node22 = {22,"�����˵�10", &Node23, NULL,NULL};
//lkdMenuNode Node21 = {21,"�����˵�9",  &Node22, NULL,NULL};
//lkdMenuNode Node20 = {20,"�����˵�8",  &Node21, NULL,NULL};

//lkdMenuNode Node19 = {19,"�����˵�7", NULL,    NULL,NULL};
//lkdMenuNode Node18 = {18,"�����˵�6", &Node19, NULL,NULL};
lkdMenuNode Node17 = {17,"�Ǳ���", NULL, NULL,&win7};
//lkdMenuNode Node16 = {16,"����������", &Node17, NULL,&win6};��


lkdMenuNode Node15 = {15,"��������", NULL, NULL,&win4_3};
lkdMenuNode Node14 = {14,"���նȴ�����", &Node15, NULL,&win4_2};
lkdMenuNode Node13 = {13,"�¶ȴ�����", &Node14, NULL,&win4_1};

//lkdMenuNode Node8 = {8,"��ʾ����             ",		NULL,	NULL,	    &win8};
lkdMenuNode Node7 = {7,"Ƕ��ʽ���UI����     ",		NULL,	NULL,	&win8};
lkdMenuNode Node6 = {6,"GPIO��Χ�豸����     ",		&Node7,	NULL,	NULL};
lkdMenuNode Node5 = {5,"���������ݲɼ�       ",		&Node6,	NULL,	NULL};
lkdMenuNode Node4 = {4,"��������Ӧ�ÿ���     ",		&Node5,	NULL,		&win3};
lkdMenuNode Node3 = {3,"LCD��ʾ����ʾӦ�ÿ���",		&Node4,	NULL,		&win2};
lkdMenuNode Node2 = {2,"������ʾӦ�ÿ���     ",		&Node3,	NULL,       NULL};
lkdMenuNode Node1 = {1,"GPIO������������     ",		&Node2,	NULL,		&win0};
lkdMenuNode Node0 = {0,"root",		NULL,	&Node1,		NULL};


/**
  *@brief  �˵����
  *@param  step ���� pNode �˵��ڵ�
  *@retval None
  */
static void MenuItemDealWith(lkdMenuNode *pNode)
{
    if(pNode->pSon != NULL) //չ��ѡ�нڵ�Ĳ˵�
    {
        GuiMenuCurrentNodeSonUnfold(&HmiMenu);
    }
    else if(pNode->user != NULL) //�򿪲˵���Ӧ�Ĵ���
    {
        GuiWinAdd(pNode->user);
    }
}

/**
  *@brief  �˵����ƺ���
  *@param  None
  *@retval None
  */
void MenuControlFun(void)
{
    switch(keyStatus)
    {
        case MKEY_UP:
            GuiMenuItemUpMove(&HmiMenu);
            break;
        case MKEY_DOWN:
            GuiMenuItemDownMove(&HmiMenu);
            break;
        case MKEY_LEFT:
        case MKEY_CANCEL:
            GuiMenuCurrentNodeHide(&HmiMenu);
            if(HmiMenu.count == 0) //��⵽�˵��˳��ź�
            {
                GuiWinDeleteTop();
            }
            break;
        case MKEY_RIGHT:
        case MKEY_OK:
            MenuItemDealWith(GuiMenuGetCurrentpNode(&HmiMenu));
            break;
    }
}

/**
  *@brief  �˵���ʼ��
  *@param  None
  *@retval None
  */
void UserMenuInit(void)
{
    HmiMenu.x = 5;
    HmiMenu.y = 55;
    HmiMenu.wide = 440;
    HmiMenu.hight = 760;
    HmiMenu.Itemshigh = 40;
    HmiMenu.ItemsWide = 200;
    HmiMenu.stack = userMenuStack;
    HmiMenu.stackNum = 8;
    HmiMenu.Root = &Node0;/* �˵�������˵��ڵ�󶨵�һ�� */
    HmiMenu.MenuDealWithFun = MenuControlFun;/* �˵����ƻص����� */
    GuiMenuInit(&HmiMenu);
}

/**
  *@brief  ���洰��ʵ��
  *@param  None
  *@retval None
  */
static void HomeFun(void *param)
{
    //�û�Ӧ�ô���:��ͼ��
    static uint8_t step;
    lkdColour forecolor = GuiGetForecolor();

    if(step == 0)
    {
        GuiFillRect(homeWin.x + 10,homeWin.y + 10,homeWin.x + 40,homeWin.y + 40,CBLACK);
        GuiRowText(32, 80+100,400, FONT_LEFT,"����1��GPIO������������ ");
        GuiRowText(32, 120+100,400, FONT_LEFT,"����2��������ʾӦ�ÿ���");
        GuiRowText(32, 160+100,400, FONT_LEFT,"����3��LCD��ʾ����ʾӦ�ÿ���");
        GuiRowText(32, 200+100,400, FONT_LEFT,"����4����������Ӧ�ÿ���");
        GuiRowText(32, 240+100,400, FONT_LEFT,"����5: ���������ݲɼ�");
        GuiRowText(32, 280+100,400, FONT_LEFT,"����6��GPIO��Χ�豸����");
        GuiRowText(32, 320+100,400, FONT_LEFT,"����7��Ƕ��ʽϵͳUI");
        GuiRowText(32, 360+100,400, FONT_RIGHT,"S1��һ��ѡ��");
        GuiRowText(32, 400+100,400, FONT_RIGHT,"S2��һ��ѡ��");
        GuiRowText(32, 440+100,400, FONT_RIGHT,"S3ȷ��");
        GuiRowText(32, 480+100,400, FONT_RIGHT,"S4����");
        GuiRowText(32, 520+100,400, FONT_RIGHT,"�밴S3����...");
        step = 1;
    }
    /* ����״̬���� */
    switch(keyStatus)
    {
        case MKEY_UP:
            break;
        case MKEY_DOWN:
            break;
        case MKEY_LEFT:
            break;
        case MKEY_RIGHT:
            break;
        case MKEY_CANCEL:
            step = 0;
            break;
        case MKEY_OK:
            step = 0;
            GuiWinAdd(&menuWin);
            break;
    }
}

/**
  *@brief  �˵�����ʵ��
  *@param  None
  *@retval None
  */
static void MenuFun(void *param)
{
    if(HmiMenu.count == 0)
    {
        GuiMenuCurrentNodeSonUnfold(&HmiMenu);
    }
    HmiMenu.MenuDealWithFun();
}

/**
  *@brief  ����0ʵ�庯��
  *@param  None
  *@retval None
  */
uint8_t Win0Fun_Task_Flag = 0;
static void Win0Fun(void *param)
{
    if(Win0Fun_Task_Flag==0)
    {
        //GuiRowText(0, 264+40,460, FONT_MID,"��������ǰ״̬����");
        GuiRowText(0, 344,460, FONT_MID,"S1����LED      ");
        GuiRowText(0, 384,460, FONT_MID,"S2����������      ");
        GuiRowText(0, 384,460, FONT_MID,"S3����������      ");
        GuiRowText(0, 424,460, FONT_MID,"S4������һ��      ");
        Win0Fun_Task_Flag=1;
    }

    switch(keyStatus)
    {
        case MKEY_UP:
            LED_Test();
            break;
        case MKEY_DOWN:
            BEEP_On();
            break;
        case MKEY_LEFT:

            break;
        case MKEY_RIGHT:
            break;
        case MKEY_CANCEL:
            GuiWinDeleteTop();
            GuiMenuRedrawMenu(&HmiMenu);
            Win0Fun_Task_Flag = 0;
            break;
        case MKEY_OK:
            break;
    }
}


struct tm tmp=
{
    .tm_sec = 0,
    .tm_min = 0,
    .tm_hour = 0,
    .tm_mday = 0,
    .tm_mon = 0,
    .tm_year = 0,
};
/**
  *@brief  ����1ʵ�庯��
  *@param  None
  *@retval None
  */
static  uint8_t sec_time=100;
static uint32_t testTick;
static uint8_t num=5;
static uint8_t num_show_flag=3;// ��ʱ�Ƿ�����־λ
uint8_t Win1Fun_Task_Flag = 0;
static void Win1Fun(void *param)
{
    if(Win1Fun_Task_Flag==0)
    {
        //GuiRowText(0, 264+40,460, FONT_MID,"LED��ǰ״̬����      ");
        //GuiRowText(0, 344,460, FONT_MID,"S1������ɫ�任       ");
        //GuiRowText(0, 384,460, FONT_MID,"S2�ر�LED            ");
        //GuiRowText(0, 420,460, FONT_MID,"S3������һ��         ");
        Win1Fun_Task_Flag=1;
    }
    //uint8_t i=0;


    //�û�Ӧ�ô���:��ͼ��
    /* ����״̬���� */
    switch(keyStatus)
    {
        case MKEY_UP://�������ʾ5
           
            break;
        case MKEY_DOWN:
            
            break;
        case MKEY_LEFT:
            break;
        case MKEY_RIGHT:
            break;
        case MKEY_CANCEL:
            GuiWinDeleteTop();
            GuiMenuRedrawMenu(&HmiMenu);
            Win1Fun_Task_Flag = 0;
            break;
        case MKEY_OK:
            break;
    }
}
/**
  *@brief  ����2ʵ�庯��
  *@param  None
  *@retval None
  */
static uint32_t testTick;
uint8_t win2Fun_Task_flag=0;
static void Win2Fun(void *param)
{
    if(win2Fun_Task_flag==0)
    {
        //GuiRowText(0, 264,460, FONT_MID,"����ʶ������");
        win2Fun_Task_flag = 1;
    }

        fb_set_bgcolor(cidxWHITE,clWHITE);
        fb_cons_clear();
        fb_fillrect(0,0,800,480,cidxBLACK);
        fb_fillrect(0,0,800,480,cidxBLACK);
        display_pic(45,50,500,400,gImage_IMG_CODE);  //��ʾͼƬ
    switch(keyStatus)
    {
        case MKEY_UP://�������ʾ5
            break;
        case MKEY_DOWN:
            break;
        case MKEY_LEFT:
            break;
        case MKEY_RIGHT:
            break;
        case MKEY_CANCEL:
            GuiWinDeleteTop();
            GuiMenuRedrawMenu(&HmiMenu);
            break;
        case MKEY_OK:
            break;
    }
}

/**
  *@brief  ����3ʵ�庯��
  *@param  None
  *@retval None
  */
static uint8_t tips=0;
static uint8_t Win3Fun_Task_Flag=0;
static uint8_t voice_data[1]= {0x01};
static void Win3Fun(void *param)
{
    if(Win3Fun_Task_Flag==0)
    {
        GuiRowText(0, 264,460, FONT_MID,"����ʶ������");
        Win3Fun_Task_Flag=1;
    }

    UART4_Test();//���ڿ��ƺ���
    tips=Voice_Drive();
    
    
    switch(tips)
    {
        case 0x01:
            GuiRowText(0, 340,460, FONT_MID,"ʵ����������");
            break;
        case 0x02:
            GuiRowText(0, 340,460, FONT_MID,"�������Բ���");
            break;
        case 0x03:
            GuiRowText(0, 340,460, FONT_MID,"���ܳɾ�����");
            break;
        case 0x04:
            GuiRowText(0, 340,460, FONT_MID,"�˲Ÿı�����");
            break;

        default:
            //
            break;
    }

    /* ����״̬���� */
    switch(keyStatus)
    {
        case MKEY_UP:
            ls1x_uart_write(devUART4,voice_data,1,NULL);//����������������
            break;
        case MKEY_DOWN://��ʾͼƬ


            break;
        case MKEY_LEFT:
            break;
        case MKEY_RIGHT:
            break;
        case MKEY_CANCEL:
            GuiWinDeleteTop();
            GuiMenuRedrawMenu(&HmiMenu);
            Win3Fun_Task_Flag=0;
            break;
        case MKEY_OK:
            break;
    }
}

/**
  *@brief  ����4_1ʵ�庯��
  *@param  None
  *@retval None
  */
float lm35_temp_data=0;
uint8_t env_temp_value=33;
uint8_t Win4_Task_flag=0;
int fan_pwm_value=0;
static void Win4_1Fun(void *param)
{
    static str[50]= {0};

    if(Win4_Task_flag==0)
    {
        IncPIDInit();
        lm35_temp_data=lm35_get_temp();
        //env_temp_value=lm35_temp_data;
        sPID.SetPoint=env_temp_value;
        sprintf(str,"�����¶���ֵ:%d�� ",env_temp_value);

        GuiRowText(0, 340,460, FONT_MID,str);
        Win4_Task_flag=1;
        gpio_write(36,1);//���ȿ������Ŵ�

    }

    Resistance_Control(1);
    lm35_temp_data=lm35_get_temp();
    sprintf(str,"��ǰ�¶ȣ�%.01f��",lm35_temp_data);
    GuiRowText(0, 264,460, FONT_MID,str);

#if 0
    sprintf(str,"PWM:%d ",fan_pwm_value);
    GuiRowText(0, 360,480, FONT_MID,str);
#endif

    printf("Ŀ���¶�%d ʵ���¶�%d\r\n",env_temp_value,(int)lm35_temp_data);
    fan_pwm_value =IncPIDCalc((int)lm35_temp_data);
    delay_ms(30);
    printf("yuan%d\r\n",(fan_pwm_value));
    if(fan_pwm_value<0)
        fan_pwm_value=2;//����ȫ�رշ��ȣ������������
    if(fan_pwm_value>100)
        fan_pwm_value=100;
    printf("out%d\r\n",(fan_pwm_value));
    Fan_Control((fan_pwm_value));

    /* ����״̬���� */
    switch(keyStatus)
    {
        case MKEY_UP:
            env_temp_value++;
            sPID.SetPoint=env_temp_value;
            sprintf(str,"�����¶���ֵ:%d�� ",env_temp_value);
            GuiRowText(0, 340,460, FONT_MID,str);
            break;
        case MKEY_DOWN:
            env_temp_value--;
            sPID.SetPoint=env_temp_value;
            sprintf(str,"�����¶���ֵ:%d�� ",env_temp_value);
            GuiRowText(0, 340,460, FONT_MID,str);
            break;
        case MKEY_LEFT:
            break;
        case MKEY_RIGHT:
            break;
        case MKEY_CANCEL:
            GuiWinDeleteTop();
            GuiMenuRedrawMenu(&HmiMenu);
            Win4_Task_flag=0;
            Fan_Control((0));
            gpio_write(36,0);//���ȿ������Źر�
            Resistance_Control(0);//�������ر�
            Fan_Control(100);//
            break;
        case MKEY_OK:
            break;
    }
}

/**
  *@brief  ����4_2ʵ�庯��
  *@param  None
  *@retval None
  */
static uint16_t light_value=0;
static void Win4_2Fun(void *param)
{
    char str[50]= {0};
    light_value=BH1750_Test();
    sprintf(str," ��ǰ������ǿ�ȣ�%d lx ",light_value);
    GuiRowText(0, 264,460, FONT_MID,str);

    /* ����״̬���� */
    switch(keyStatus)
    {
        case MKEY_UP:
            break;
        case MKEY_DOWN://��ʾͼƬ

            break;
        case MKEY_LEFT:
            break;
        case MKEY_RIGHT:
            break;
        case MKEY_CANCEL:
            GuiWinDeleteTop();
            GuiMenuRedrawMenu(&HmiMenu);
            break;
        case MKEY_OK:
            break;
    }
}

/**
  *@brief  ����4_3ʵ�庯��
  *@param  None
  *@retval None
  */
char *dir_info[]= {" ���򣺶� "," ������ "," ������ "," ���򣺱� ","���򣺶���","��������","���򣺶���","��������"};
uint8_t dir_flag=0;
static Win4_task_flag=0;
static void Win4_3Fun(void *param)
{
    char str[50]= {0};
    double angle;

    if(Win4_task_flag==0)
    {

        HCM5883L_Init();
        Win4_task_flag=1;
    }



    angle=HCM5883L_Get_Angle();
    angle=360-angle;
    angle-=360;
    angle*=-1;
    sprintf(str,"  �Ƕȣ�%.1f �� ",angle);

    GuiRowText(32, 340,460, FONT_MID,str);


    if((angle>=338&&angle<=359)||(angle>=0&&angle<=21))//��
    {
        dir_flag=3;
    }
    else    if(angle>=22&&angle<=66)  //����
    {
        dir_flag=6;
    }
    else  if(angle>=67&&angle<=111)//��
    {
        dir_flag=0;

    }
    else   if(angle>=112&&angle<=157)    //����
    {
        dir_flag=4;
    }
    else   if(angle>=158&&angle<=202)//��
    {
        dir_flag=1;
    }
    else    if(angle>=203&&angle<=246)   //����
    {
        dir_flag=5;
    }
    else    if(angle>=247&&angle<=288)//��
    {
        dir_flag=2;
    }
    else    if(angle>=292&&angle<=337)//����
    {
        dir_flag=7;
    }
    GuiRowText(0, 400,460, FONT_MID,dir_info[dir_flag]);//��ʾ����

    /* ����״̬���� */
    switch(keyStatus)
    {
        case MKEY_UP:

            break;
        case MKEY_DOWN://��ʾͼƬ

            break;
        case MKEY_LEFT:
            break;
        case MKEY_RIGHT:
            break;
        case MKEY_CANCEL:
            GuiWinDeleteTop();
            GuiMenuRedrawMenu(&HmiMenu);
            Win4_task_flag=0;
            break;
        case MKEY_OK:
            break;
    }
}

/**
  *@brief  ����5ʵ�庯��
  *@param  None
  *@retval None
  */
static uint16_t motor_show_speed=0;
static uint16_t env_motor_show_speed=0;
static void Win5Fun(void *param)
{
    char str[50]= {0};
    motor_show_speed=  Motor_Speed_Check();
    sprintf(str," ��ǰ���ת�٣�%d rpm ",motor_show_speed);
    GuiRowText(0, 264,460, FONT_MID,str);
    delay_ms(80);
    /* ����״̬���� */
    switch(keyStatus)
    {
        case MKEY_UP:
            //set_lcd_brightness(0);
            env_motor_show_speed+=10;
            if(env_motor_show_speed>50)
            {
                env_motor_show_speed=50;
            }
            set_lcd_brightness(env_motor_show_speed);
            printf("%d\r\n",env_motor_show_speed);
            break;
        case MKEY_DOWN://
            //set_lcd_brightness(20);
            if(env_motor_show_speed<=0)
            {
                env_motor_show_speed=0;
            }
            else
            {
                env_motor_show_speed-=10;
            }
            set_lcd_brightness(env_motor_show_speed);
            printf("%d\r\n",env_motor_show_speed);
            break;
        case MKEY_LEFT:

            break;
        case MKEY_RIGHT:
            break;
        case MKEY_CANCEL:
            GuiWinDeleteTop();
            GuiMenuRedrawMenu(&HmiMenu);
            set_lcd_brightness(100);//�˳�ʱ�رյ��
            break;
        case MKEY_OK:
            set_lcd_brightness(100);
            break;
    }
}
/**
  *@brief  ����6ʵ�庯��
  *@param  None
  *@retval None
  */
static uint8_t Win6_Fun_Task_Flag=0;
float dis_value=0;//����������ֵ
static uint16_t  env_dis_value=20;//������������ֵ��λ����
static uint16_t motor_set_speed=0;
static int motor_set_pwm=0;
static int motor_handler_flag=0;
static void Win6Fun(void *param)
{
    char str[50]= {0};
    if(Win6_Fun_Task_Flag==0)
    {
        Win6_Fun_Task_Flag=1;
        PWM2_Time_Init();
        Ultrasonic_IO_Config();
        Inc_MOTOR_PIDInit();
        //�������
        set_lcd_brightness(0);
        sprintf(str," ������������ֵ��%d cm ",env_dis_value);
        sptr1->SetPoint=env_dis_value;
        GuiRowText(0, 210,460, FONT_MID,str);
    }
    dis_value=Ultrasonic_Get_Dist();
    sprintf(str," ���������룺%.02f cm ",dis_value);
    GuiRowText(0, 164,460, FONT_MID,str);


    motor_show_speed=  Motor_Speed_Check();

    sprintf(str," ���ת�٣�%d rpm ",(motor_show_speed));
    GuiRowText(0, 264,460, FONT_MID,str);
    if(dis_value<10)//С��10cm
    {
        set_lcd_brightness(100);
    }
    else if(dis_value<env_dis_value) //��
    {
        motor_set_pwm++;
        if(motor_set_pwm>100)
        {
            motor_set_pwm=100;
        }
        set_lcd_brightness(motor_set_pwm);
    }
    else//��
    {
        motor_set_pwm-=5;
        if(motor_set_pwm<0)
        {
            motor_set_pwm=0;
        }
        set_lcd_brightness(0);
    }



    /* ����״̬���� */
    switch(keyStatus)
    {
        case MKEY_UP:
            env_dis_value++;
            sprintf(str," ������������ֵ��%d cm ",env_dis_value);
            GuiRowText(0, 210,460, FONT_MID,str);
            break;
        case MKEY_DOWN://��ʾͼƬ
            env_dis_value--;
            sprintf(str," ������������ֵ��%d cm ",env_dis_value);
            GuiRowText(0, 210,460, FONT_MID,str);
            break;
        case MKEY_LEFT:
            break;
        case MKEY_RIGHT:
            break;
        case MKEY_CANCEL:
            GuiWinDeleteTop();
            GuiMenuRedrawMenu(&HmiMenu);
            Win6_Fun_Task_Flag=1;
            break;
        case MKEY_OK:
            break;
    }
}

/**
  *@brief  ����7ʵ�庯��
  *@param  None
  *@retval None
  */
static Win7_Task_flag=0;
gauge_dev gauge_speed= {120,200,60,0,225};
gauge_dev gauge_dis= {350,200,60,0,225};
gauge_dev gauge_hmc5883= {240,550,130,0,90};

static void Win7Fun(void *param)
{
    double angle;
    char str[50];
    if(Win7_Task_flag==0)
    {
        sprintf(str," ��ֵ��%d cm ",env_dis_value);
        GuiRowText(0, 65,460, FONT_MID,str);
        HCM5883L_Init();
        gauge_create(&gauge_speed);
        gauge_create(&gauge_dis);
        gauge_create(&gauge_hmc5883);
        //OLED_DrawAngleLine_Font_struct(&gauge_hmc5883,0,"0");

        OLED_DrawAngleLine_Font_struct(&gauge_dis,0,"0");
        OLED_DrawAngleLine_Font_struct(&gauge_dis,45,"5");
        OLED_DrawAngleLine_Font_struct(&gauge_dis,90,"10");
        OLED_DrawAngleLine_Font_struct(&gauge_dis,135,"15");
        OLED_DrawAngleLine_Font_struct(&gauge_dis,180,"20");
        OLED_DrawAngleLine_Font_struct(&gauge_dis,225,"25");
        OLED_DrawAngleLine_Font_struct(&gauge_dis,270,"30");


        OLED_DrawAngleLine_Font_struct(&gauge_speed,0,"0");
        OLED_DrawAngleLine_Font_struct(&gauge_speed,45,"65");
        OLED_DrawAngleLine_Font_struct(&gauge_speed,90,"130");
        OLED_DrawAngleLine_Font_struct(&gauge_speed,135,"195");
        OLED_DrawAngleLine_Font_struct(&gauge_speed,180,"260");
        OLED_DrawAngleLine_Font_struct(&gauge_speed,225,"325");
        OLED_DrawAngleLine_Font_struct(&gauge_speed,270,"390");

        OLED_DrawAngleLine_Font_struct(&gauge_hmc5883,30,"30");
        OLED_DrawAngleLine_Font_struct(&gauge_hmc5883,60,"60");
        OLED_DrawAngleLine_Font_struct(&gauge_hmc5883,90,"90");
        OLED_DrawAngleLine_Font_struct(&gauge_hmc5883,120,"120");
        OLED_DrawAngleLine_Font_struct(&gauge_hmc5883,150,"150");
        OLED_DrawAngleLine_Font_struct(&gauge_hmc5883,180,"180");
        OLED_DrawAngleLine_Font_struct(&gauge_hmc5883,210,"210");
        OLED_DrawAngleLine_Font_struct(&gauge_hmc5883,240,"240");
        OLED_DrawAngleLine_Font_struct(&gauge_hmc5883,270,"270");
        OLED_DrawAngleLine_Font_struct(&gauge_hmc5883,300,"300");
        OLED_DrawAngleLine_Font_struct(&gauge_hmc5883,330,"330");
        OLED_DrawAngleLine_Font_struct(&gauge_hmc5883,360,"360");
    }



    angle=HCM5883L_Get_Angle();
    gauge_hmc5883.angle=angle;
    angle=360-angle;
    angle-=360;
    angle*=-1;

    sprintf(str,"  �Ƕȣ�%.1f �� ",angle);
    GuiRowText(32, 750,460, FONT_LEFT,str);


    if((angle>=338&&angle<=359)||(angle>=0&&angle<=21))//��
    {
        dir_flag=3;
    }
    else    if(angle>=22&&angle<=66)  //����
    {
        dir_flag=6;
    }
    else  if(angle>=67&&angle<=111)//��
    {
        dir_flag=0;
    }
    else   if(angle>=112&&angle<=157)    //����
    {
        dir_flag=4;
    }
    else   if(angle>=158&&angle<=202)//��
    {
        dir_flag=1;
    }
    else    if(angle>=203&&angle<=246)   //����
    {
        dir_flag=5;
    }
    else    if(angle>=247&&angle<=288)//��
    {
        dir_flag=2;
    }
    else    if(angle>=292&&angle<=337)//����
    {
        dir_flag=7;
    }
    GuiRowText(0, 750,460, FONT_RIGHT,dir_info[dir_flag]);//��ʾ����

    set_gauge_value(&gauge_hmc5883);


    dis_value=Ultrasonic_Get_Dist();

    if(dis_value>30)
    {
        dis_value=30.0;
    }
    sprintf(str," %.02f cm ",dis_value);
    GuiRowText(0, 320,460, FONT_RIGHT,str);
    gauge_dis.angle=(double)dis_value*9;
    set_gauge_value(&gauge_dis);


    motor_show_speed=  Motor_Speed_Check();

    if(dis_value<10)//С��10cm
    {
        set_lcd_brightness(100);
    }
    else if(dis_value<env_dis_value) //��
    {
        motor_set_pwm++;
        if(motor_set_pwm>100)
        {
            motor_set_pwm=100;
        }
        set_lcd_brightness(motor_set_pwm);
    }
    else//��
    {
        motor_set_pwm-=5;
        if(motor_set_pwm<0)
        {
            motor_set_pwm=0;
        }
        set_lcd_brightness(0);
    }


    sprintf(str," %d rpm ",(motor_show_speed));
    GuiRowText(64, 320,460, FONT_LEFT,str);
    gauge_speed.angle=(motor_show_speed)*0.69;
    set_gauge_value(&gauge_speed);


    /* ����״̬���� */
    switch(keyStatus)
    {
        case MKEY_UP:
            env_dis_value++;
            sprintf(str," ��ֵ��%d cm ",env_dis_value);
            GuiRowText(0, 65,460, FONT_MID,str);
            break;
        case MKEY_DOWN://��ʾͼƬ
            env_dis_value--;
            sprintf(str," ��ֵ��%d cm ",env_dis_value);
            GuiRowText(0, 65,460, FONT_MID,str);
            break;
        case MKEY_LEFT:
            break;
        case MKEY_RIGHT:
            break;
        case MKEY_CANCEL:
            GuiWinDeleteTop();
            GuiMenuRedrawMenu(&HmiMenu);
            break;
        case MKEY_OK:
            break;
    }
}


/**
  *@brief  ����8ʵ�庯��
  *@param  None
  *@retval None
  */
unsigned short int WaveData[672];
uint8_t win8Fun_Task_flag=0;
static void Win8Fun(void *param)
{
    unsigned short int light = 0;
    //�û�Ӧ�ô���:��ͼ��
    if(win8Fun_Task_flag==0)//ִֻ��һ��
    {
        win8Fun_Task_flag = 1;
        //�����Ļ��ˢ����ʾ����ɫ
        fb_cons_clear();
        /*�����Ļ�����ñ�����ɫΪ��ɫ*/
        fb_fillrect(0,0,800,480,cidxGREY);
    }
    Wave();
    /* ����״̬���� */
    switch(keyStatus)
    {
        case MKEY_UP:
            break;
        case MKEY_DOWN://��ʾͼƬ

            break;
        case MKEY_LEFT:
            break;
        case MKEY_RIGHT:
            break;
        case MKEY_CANCEL:
            GuiWinDeleteTop();
            GuiMenuRedrawMenu(&HmiMenu);
            break;
        case MKEY_OK:
            break;
    }
}


#if 0
/**
  *@brief  ����4ʵ�庯��
  *@param  None
  *@retval None
  */
static void Win4Fun(void *param)
{
    /* ����״̬���� */
    switch(keyStatus)
    {
        case MKEY_UP:

            break;
        case MKEY_DOWN://��ʾͼƬ

            break;
        case MKEY_LEFT:
            break;
        case MKEY_RIGHT:
            break;
        case MKEY_CANCEL:
            GuiWinDeleteTop();
            GuiMenuRedrawMenu(&HmiMenu);
            break;
        case MKEY_OK:
            break;
    }
}

#endif
/**
  *@brief  �û��˵�������
  *@param  None
  *@retval None
  */
void userAppMain(void)
{
    keyStatus = GetMenuKeyState();
    SetMenuKeyIsNoKey();
}

/**
  *@brief  �û�Ӧ�ó�ʼ��
  *@param  None
  *@retval None
  */
void userAppInit(void)
{
    UserMenuInit();
    GuiSetForecolor(1);
    GuiSetbackcolor(0);
    GuiWinAdd(&homeWin);
}


void Border(void)
{
    uint8_t fillrect_flag = 0;
    unsigned short int X = 80;
    unsigned short int Y = 108;
    int i;

    /*��ʾ����ǿ�ȴ�������ֵ*/
    char sensor_values[7][4] = {"0", "100", "200", "300", "400", "500", "600"};
    for (i = 0; i < 7; i++)
    {
        fb_textout(40, 400 - 50 * i, sensor_values[i]);
    }

    /*�����ɫ*/
    /*ִֻ��һ��*/
    //if(fillrect_flag == 0)
    //{
    //fillrect_flag = 1;
    //fb_fillrect(80,408,756,108,cidxGREY);
    //}

    /*X��*/
    for (i = 0; i < 7; i++)
    {
        fb_drawline(X, Y + 50 * i, 756, Y + 50 * i, cidxBRTWHITE);
    }

    /*Y��*/
    for (i = 0; i < 9; i++)
    {
        fb_drawline(X + 84 * i, Y, X + 84 * i, 408, cidxBRTWHITE);
    }

    /*ʱ����Ϣ*/
    fb_textout(80, 425, "0");
    fb_textout(750-75-75-75-75-75-75-75-75-12, 425, "0.5");
    fb_textout(750-75-75-75-75-75-75-75-12, 425, "1.0");
    fb_textout(750-75-75-75-75-75-75-12, 425, "1.5");
    fb_textout(750-75-75-75-75-75-12, 425, "2.0");
    fb_textout(750-75-75-75-75-12, 425, "2.5");
    fb_textout(750-75-75-75-12, 425, "3.0");
    fb_textout(750-75-75-12, 425, "3.5");
    fb_textout(750-75-12, 425, "4.0");
    fb_textout(750-12, 425, "4.5");
}

void LightWave(unsigned char num)
{
    unsigned int PointX, PointY;
    unsigned int Xtime;
    unsigned int range = 300;
    unsigned int PointXlast, PointYlast;

    float scale = (float)range / 600;
    PointX = 80;
    for(Xtime = 80; Xtime < 756; Xtime+=num)
    {
        char str[50]= {0};
        sprintf(str,"%d",light_value);
        fb_textout(150, 35, str);

        PointXlast = PointX;
        PointYlast = PointY;
        PointX = Xtime;
        light_value=BH1750_Test();
        PointY = light_value * scale;
        fb_drawline(PointXlast, 408-PointYlast, PointX, 408-PointY, cidxBRTGREEN);
        delay_ms(50);
        fb_fillrect(150, 35, 150+30, 65, cidxGREY);
    }
}

#define MAX_WAVE_DATA 672
#define POINT_X_START 80
#define POINT_Y_START 408
#define RANGE_01 108
#define RANGE_02 0

void Wave(void)
{
    unsigned int range = 300;
    float scale = (float)range / 600;
    unsigned short int Xtime, PointX = POINT_X_START, PointY, PointXlast, PointYlast;
    unsigned short int light;
    char str[50] = {0};
    char light_str[10] = {0};
    unsigned char buf[20] = {0};
    light = BH1750_Test();


    while (light != 0)
    {
        light_value = light * scale;
        for (Xtime = MAX_WAVE_DATA - 1; Xtime > 0; Xtime--)
        {
            WaveData[Xtime] = WaveData[Xtime - 1];
        }

        if (light > 0 && light < 600)
        {
            WaveData[0] = light_value;
        }
        if (light > 600)
        {
            WaveData[0] = RANGE_01;
        }
        //else if (light == 0)
        //{
        //WaveData[0] = RANGE_02;
        //}
        //fb_textout(20, 35, "��ǰ������ǿ�ȣ�");
        //sprintf((char *)buf,"%d lux", light);
        //fb_textout(150, 35, buf);
        //delay_ms(100);
        //fb_fillrect(150, 35, 70, 60, cidxBLACK);

        fb_cons_clear();

        unsigned char Border_flag = 1;
        if(Border_flag == 1)
        {
            Border();
            Border_flag == 0;
        }
        // ���Ʋ���
        for (Xtime = 0; Xtime < MAX_WAVE_DATA; Xtime++)
        {
            fb_drawline(PointX + Xtime, POINT_Y_START - WaveData[Xtime], PointX + Xtime + 1, POINT_Y_START - WaveData[Xtime + 1], cidxBRTGREEN);
        }
        light = BH1750_Test();
    }
}
