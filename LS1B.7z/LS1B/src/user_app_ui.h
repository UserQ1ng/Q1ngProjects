/*
 * user_app_ui.h
 *
 * created: 2022/7/13
 *  author: 
 */

#ifndef _USER_APP_UI_H
#define _USER_APP_UI_H

void userAppMain(void);
void userAppInit(void);

#endif // _USER_APP_UI_H

