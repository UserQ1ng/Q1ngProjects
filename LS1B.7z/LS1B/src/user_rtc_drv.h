/*
 * user_rtc_drv.h
 *
 * created: 2022/7/13
 *  author:
 */

#ifndef _USER_RTC_DRV_H
#define _USER_RTC_DRV_H
#include "ls1x_rtc.h"
void user_rtc_init(void);

#endif // _USER_RTC_DRV_H

