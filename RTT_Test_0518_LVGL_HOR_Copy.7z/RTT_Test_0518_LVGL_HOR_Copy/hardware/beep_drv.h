/*
 * beep_drv.h
 *
 * created: 2024/5/22
 *  author: 
 */

#ifndef _BEEP_DRV_H
#define _BEEP_DRV_H

#ifdef __cplusplus
extern "C" {
#endif

#include "bsp.h"
#include "tick.h"
#include "ls1b_gpio.h"

#define ON  1
#define OFF 0

#define BEEP_PORT 46
#define BEEP_ENABLE(PIN)  gpio_enable(PIN, DIR_OUT)
#define BEEP_OFF(PIN)     gpio_write(PIN,OFF)
#define BEEP_ON(PIN)      gpio_write(PIN,ON)

void beep_init(void);    //��������ʼ��

void play_music(unsigned char *music, unsigned char *times, size_t length);     //��������������
void sound(unsigned short frq);
//void play_music(void);

#ifdef __cplusplus
}
#endif

#endif // _BEEP_DRV_H

