/*
 * bkrc_voice.c
 *
 * created: 2024/5/22
 *  author: 
 */
#include "bkrc_voice.h"

unsigned char Voice_Drive(void)
{
    unsigned char voice_status = 0;
    if (buff[0] == 0x55)			// �Զ�������֡�������
    {
        if (buff[1] == 0x02)
        {

            switch (buff[2])
            {
                case 0x01:
                    //USART2_Send_Byte(0x01);
                    //                printf("* �������� *");
                    voice_status = 0x01;
                    break;

                case 0x02:
                    //USART2_Send_Byte(0x02);
                    //                printf("* ����ɽ�� *");
                    voice_status = 0x02;
                break;

                case 0x03:
                    //USART2_Send_Byte(0x03);
                    //                printf("* ׷������ *");
                    voice_status = 0x03;
                break;

                case 0x04:
                    //USART2_Send_Byte(0x04);
                    //                printf("* �﷫���� *");
                    voice_status = 0x04;
                break;

                case 0x05:
                    //USART2_Send_Byte(0x05);
                    //                printf("* ��ͷ���� *");
                    voice_status = 0x05;
                break;

                case 0x06:
                    //USART2_Send_Byte(0x05);
                    //                printf("* ��ͷ���� *");
                    voice_status = 0x06;
                    break;
                case 0x07:
                    //USART2_Send_Byte(0x05);
                    //                printf("* ��ͷ���� *");
                    voice_status = 0x07;
                    break;

                default  :
                    break;
            }
        }
        else if(buff[1] == 0x01)
        {
            if(buff[2] == 0x03)
            {
                voice_status = 0x30;
            }
            else if(buff[2] == 0x02)
            {
                voice_status = 0x20;
            }
        }
    }
    else if(buff[0] != 0x55)
    {
        voice_status = 0;
    }
    return voice_status;
}




