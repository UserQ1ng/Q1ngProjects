/*
 * bkrc_voice.h
 *
 * created: 2024/5/22
 *  author: 
 */

#ifndef _BKRC_VOICE_H
#define _BKRC_VOICE_H

#ifdef __cplusplus
extern "C" {
#endif

#include "uart.h"
#include "ls1b.h"
#include "ls1b_gpio.h"
#include "ns16550.h"
#include "stdio.h"
#include "string.h"

unsigned char Voice_Drive(void);

#ifdef __cplusplus
}
#endif

#endif // _BKRC_VOICE_H

