/*
 * led_drv.c
 *
 * created: 2024/5/21
 *  author: 
 */
#include "led_drv.h"


void led_init(void)
{
    //����IO�ڶ����ó����ģʽ
    gpio_enable(RED_LED, DIR_OUT);
    gpio_enable(GREEN_LED, DIR_OUT);
    gpio_enable(BLUE_LED, DIR_OUT);

    //��ʼ��Ϩ��
    RGB_OFF;
}

void led_test(void)
{
    RED_ON;
    rt_thread_mdelay(500);
    RED_OFF;
    GREEN_ON;
    rt_thread_mdelay(500);
    GREEN_OFF;
    BLUE_ON;
    rt_thread_mdelay(500);
    BLUE_OFF;
}


