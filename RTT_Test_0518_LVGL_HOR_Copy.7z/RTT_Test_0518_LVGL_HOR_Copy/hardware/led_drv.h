/*
 * led_drv.h
 *
 * created: 2024/5/21
 *  author: 
 */

#ifndef _LED_DRV_H
#define _LED_DRV_H

#ifdef __cplusplus
extern "C" {
#endif

#include "bsp.h"
#include "tick.h"
#include "ls1b_gpio.h"
#include "rtthread.h"


//------------------------------------------
// �˿ں궨��
//------------------------------------------
#define  RED_LED    34
#define  GREEN_LED  37
#define  BLUE_LED   35

//------------------------------------------
// �����궨�壨��/��/�л���
//------------------------------------------
#define  RED_ON     gpio_write(RED_LED, 1)
#define  GREEN_ON	gpio_write(GREEN_LED, 1)
#define  BLUE_ON	gpio_write(BLUE_LED, 1)
#define  RED_OFF	gpio_write(RED_LED, 0)
#define  GREEN_OFF	gpio_write(GREEN_LED, 0)
#define  BLUE_OFF	gpio_write(BLUE_LED, 0)
#define  RED_TOG	gpio_write(RED_LED, !gpio_read(RED_LED))
#define  GREEN_TOG	gpio_write(GREEN_LED, !gpio_read(GREEN_LED))
#define  BLUE_TOG	gpio_write(BLUE_LED, !gpio_read(BLUE_LED))
#define  RGB_ON     {RED_ON; GREEN_ON; BLUE_ON;}
#define  RGB_OFF    {RED_OFF; GREEN_OFF; BLUE_OFF;}

void led_test(void);

#ifdef __cplusplus
}
#endif

#endif // _LED_DRV_H

