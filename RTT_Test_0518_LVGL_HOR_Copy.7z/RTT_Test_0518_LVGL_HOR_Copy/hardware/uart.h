/*
 * uart.h
 *
 * created: 2024/5/22
 *  author: 
 */

#ifndef _UART_H
#define _UART_H

#ifdef __cplusplus
extern "C" {
#endif

#include "uart.h"
#include "ls1b.h"
#include "ls1b_gpio.h"
#include "ns16550.h"
#include "stdio.h"
#include "string.h"
#include "stdint.h"

#define UART4  devUART4 //����ģ��        ��bsp.h��ȡ��devUART4��ע�Ϳ�������
#define UART5  devUART5 //USB-TTL
#define UART_WIRTE(UARTX, BUFF, SIZE)  ls1x_uart_write(UARTX, BUFF, SIZE, NULL)

extern char buff[256];

void uart_init(void *dev_uart, unsigned int BaudRate);
void uart4_test(void);




#ifdef __cplusplus
}
#endif

#endif // _UART_H

