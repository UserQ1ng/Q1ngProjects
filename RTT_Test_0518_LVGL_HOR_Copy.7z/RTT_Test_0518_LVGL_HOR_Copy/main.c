/*
 * Copyright (C) 2020-2021 Suzhou Tiancheng Software Ltd.
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * Loongson 1B RT-Thread Application
 */

#include <time.h>

#include "rtthread.h"

//-------------------------------------------------------------------------------------------------
// BSP
//-------------------------------------------------------------------------------------------------

#include "bsp.h"
#include "ls1x_fb.h"
#include "RT_Thread_Demo.h"
char LCD_display_mode[] = LCD_800x480;




int lv_tick_suspend(void)
{
    if (p_lv_tick_thread == NULL)
        return 0;
    return -rt_thread_suspend(p_lv_tick_thread);
}

int lv_tick_resume(void)
{
    if (p_lv_tick_thread == NULL)
        return 0;
    return -rt_thread_resume(p_lv_tick_thread);
}

int lv_tick_delete(void)
{
    int rt;
    if (p_lv_tick_thread == NULL)
        return 0;

    rt = rt_thread_delete(p_lv_tick_thread);
    if (rt == RT_EOK)
        p_lv_tick_thread = NULL;

    return -rt;
}

//-------------------------------------------------------------------------------------------------
// Simple demo of task
//-------------------------------------------------------------------------------------------------


//-------------------------------------------------------------------------------------------------

int main(int argc, char** argv)
{
    rt_kprintf("\r\nWelcome to RT-Thread.\r\n\r\n");

    ls1x_drv_init();            /* Initialize device drivers */

    rt_ls1x_drv_init();         /* Initialize device drivers for RTT */

    
    install_3th_libraries(); 	/* Install 3th libraies */

	lv_tick_create(1);
    /*
     * Task initializing...
     */
                                     
    rt_thread_start_task();

    /*
     * Finsh as another thread...
     */
    return 0;
}

/*
 * @@ End
 */
