/*
 * user_app.h
 *
 * created: 2023/5/18
 *  author: 
 */

#ifndef _USER_APP_H
#define _USER_APP_H

#ifdef __cplusplus
extern "C" {
#endif

#include "rtthread.h"
#include "lvgl-7.0.1/lvgl.h"

#include "beep_drv.h"
#include "bkrc_voice.h"
#include "led_drv.h"
#include "uart.h"

extern int main_btnm_cb_flag;
extern int test_btnm_cb_flag;
extern int main_task_flag;
extern int test_task_flag;

/*---------------------------- ����ť���󲼾� --------------------------*/
static const char *btnm_main_map[] = {"""\xE4\xB8\xBB"/*��*/"""\xE4\xBB\xBB"/*��*/"""\xE5\x8A\xA1"/*��*/"1", "\n",
                                      """\xE4\xB8\xBB"/*��*/"""\xE4\xBB\xBB"/*��*/"""\xE5\x8A\xA1"/*��*/"2", "\n",
                                      """\xE4\xB8\xBB"/*��*/"""\xE4\xBB\xBB"/*��*/"""\xE5\x8A\xA1"/*��*/"3", "\n",
                                      """\xE4\xB8\xBB"/*��*/"""\xE4\xBB\xBB"/*��*/"""\xE5\x8A\xA1"/*��*/"4", "\n",
                                      """\xE4\xB8\xBB"/*��*/"""\xE4\xBB\xBB"/*��*/"""\xE5\x8A\xA1"/*��*/"5", "\n",
                                      """\xE4\xB8\xBB"/*��*/"""\xE4\xBB\xBB"/*��*/"""\xE5\x8A\xA1"/*��*/"6", "\n",
                                      """\xE4\xB8\xBB"/*��*/"""\xE4\xBB\xBB"/*��*/"""\xE5\x8A\xA1"/*��*/"7", "\n",
                                      """\xE4\xB8\xBB"/*��*/"""\xE4\xBB\xBB"/*��*/"""\xE5\x8A\xA1"/*��*/"8", "\n",
                                      """\xE4\xB8\xBB"/*��*/"""\xE4\xBB\xBB"/*��*/"""\xE5\x8A\xA1"/*��*/"9", ""};
/*----------------------------------------------------------------------*/

/*---------------------------- �Ӱ�ť���󲼾� --------------------------*/
static const char *btnm_test_map0[] = {""};
                                       
static const char *btnm_test_map1[] = {"""\xE5\xAD\x90"/*��*/"""\xE4\xBB\xBB"/*��*/"""\xE5\x8A\xA1"/*��*/"1.1", "\n",
                                       """\xE5\xAD\x90"/*��*/"""\xE4\xBB\xBB"/*��*/"""\xE5\x8A\xA1"/*��*/"1.2", "\n",
                                       """\xE5\xAD\x90"/*��*/"""\xE4\xBB\xBB"/*��*/"""\xE5\x8A\xA1"/*��*/"1.3", "\n",
                                       """\xE5\xAD\x90"/*��*/"""\xE4\xBB\xBB"/*��*/"""\xE5\x8A\xA1"/*��*/"1.4", "\n",
                                       """\xE5\xAD\x90"/*��*/"""\xE4\xBB\xBB"/*��*/"""\xE5\x8A\xA1"/*��*/"1.5", "",};
                                       
static const char *btnm_test_map2[] = {"""\xE5\xAD\x90"/*��*/"""\xE4\xBB\xBB"/*��*/"""\xE5\x8A\xA1"/*��*/"2.1", "\n",
                                       """\xE5\xAD\x90"/*��*/"""\xE4\xBB\xBB"/*��*/"""\xE5\x8A\xA1"/*��*/"2.2", "\n",
                                       """\xE5\xAD\x90"/*��*/"""\xE4\xBB\xBB"/*��*/"""\xE5\x8A\xA1"/*��*/"2.3", "\n",
                                       """\xE5\xAD\x90"/*��*/"""\xE4\xBB\xBB"/*��*/"""\xE5\x8A\xA1"/*��*/"2.4", "\n",
                                       """\xE5\xAD\x90"/*��*/"""\xE4\xBB\xBB"/*��*/"""\xE5\x8A\xA1"/*��*/"2.5", "",};
                                       
static const char *btnm_test_map3[] = {"""\xE5\xAD\x90"/*��*/"""\xE4\xBB\xBB"/*��*/"""\xE5\x8A\xA1"/*��*/"3.1", "\n",
                                       """\xE5\xAD\x90"/*��*/"""\xE4\xBB\xBB"/*��*/"""\xE5\x8A\xA1"/*��*/"3.2", "\n",
                                       """\xE5\xAD\x90"/*��*/"""\xE4\xBB\xBB"/*��*/"""\xE5\x8A\xA1"/*��*/"3.3", "\n",
                                       """\xE5\xAD\x90"/*��*/"""\xE4\xBB\xBB"/*��*/"""\xE5\x8A\xA1"/*��*/"3.4", "\n",
                                       """\xE5\xAD\x90"/*��*/"""\xE4\xBB\xBB"/*��*/"""\xE5\x8A\xA1"/*��*/"3.5", "",};
                                       
static const char *btnm_test_map4[] = {"""\xE5\xAD\x90"/*��*/"""\xE4\xBB\xBB"/*��*/"""\xE5\x8A\xA1"/*��*/"4.1", "\n",
                                       """\xE5\xAD\x90"/*��*/"""\xE4\xBB\xBB"/*��*/"""\xE5\x8A\xA1"/*��*/"4.2", "\n",
                                       """\xE5\xAD\x90"/*��*/"""\xE4\xBB\xBB"/*��*/"""\xE5\x8A\xA1"/*��*/"4.3", "\n",
                                       """\xE5\xAD\x90"/*��*/"""\xE4\xBB\xBB"/*��*/"""\xE5\x8A\xA1"/*��*/"4.4", "\n",
                                       """\xE5\xAD\x90"/*��*/"""\xE4\xBB\xBB"/*��*/"""\xE5\x8A\xA1"/*��*/"4.5", "",};
                                       
static const char *btnm_test_map5[] = {"""\xE5\xAD\x90"/*��*/"""\xE4\xBB\xBB"/*��*/"""\xE5\x8A\xA1"/*��*/"5.1", "\n",
                                       """\xE5\xAD\x90"/*��*/"""\xE4\xBB\xBB"/*��*/"""\xE5\x8A\xA1"/*��*/"5.2", "\n",
                                       """\xE5\xAD\x90"/*��*/"""\xE4\xBB\xBB"/*��*/"""\xE5\x8A\xA1"/*��*/"5.3", "\n",
                                       """\xE5\xAD\x90"/*��*/"""\xE4\xBB\xBB"/*��*/"""\xE5\x8A\xA1"/*��*/"5.4", "\n",
                                       """\xE5\xAD\x90"/*��*/"""\xE4\xBB\xBB"/*��*/"""\xE5\x8A\xA1"/*��*/"5.5", "",};
                                       
static const char *btnm_test_map6[] = {"""\xE5\xAD\x90"/*��*/"""\xE4\xBB\xBB"/*��*/"""\xE5\x8A\xA1"/*��*/"6.1", "\n",
                                       """\xE5\xAD\x90"/*��*/"""\xE4\xBB\xBB"/*��*/"""\xE5\x8A\xA1"/*��*/"6.2", "\n",
                                       """\xE5\xAD\x90"/*��*/"""\xE4\xBB\xBB"/*��*/"""\xE5\x8A\xA1"/*��*/"6.3", "\n",
                                       """\xE5\xAD\x90"/*��*/"""\xE4\xBB\xBB"/*��*/"""\xE5\x8A\xA1"/*��*/"6.4", "\n",
                                       """\xE5\xAD\x90"/*��*/"""\xE4\xBB\xBB"/*��*/"""\xE5\x8A\xA1"/*��*/"6.5", "",};
                                       
static const char *btnm_test_map7[] = {"""\xE5\xAD\x90"/*��*/"""\xE4\xBB\xBB"/*��*/"""\xE5\x8A\xA1"/*��*/"7.1", "\n",
                                       """\xE5\xAD\x90"/*��*/"""\xE4\xBB\xBB"/*��*/"""\xE5\x8A\xA1"/*��*/"7.2", "\n",
                                       """\xE5\xAD\x90"/*��*/"""\xE4\xBB\xBB"/*��*/"""\xE5\x8A\xA1"/*��*/"7.3", "\n",
                                       """\xE5\xAD\x90"/*��*/"""\xE4\xBB\xBB"/*��*/"""\xE5\x8A\xA1"/*��*/"7.4", "\n",
                                       """\xE5\xAD\x90"/*��*/"""\xE4\xBB\xBB"/*��*/"""\xE5\x8A\xA1"/*��*/"7.5", "",};
                                       
static const char *btnm_test_map8[] = {"""\xE5\xAD\x90"/*��*/"""\xE4\xBB\xBB"/*��*/"""\xE5\x8A\xA1"/*��*/"8.1", "\n",
                                       """\xE5\xAD\x90"/*��*/"""\xE4\xBB\xBB"/*��*/"""\xE5\x8A\xA1"/*��*/"8.2", "\n",
                                       """\xE5\xAD\x90"/*��*/"""\xE4\xBB\xBB"/*��*/"""\xE5\x8A\xA1"/*��*/"8.3", "\n",
                                       """\xE5\xAD\x90"/*��*/"""\xE4\xBB\xBB"/*��*/"""\xE5\x8A\xA1"/*��*/"8.4", "\n",
                                       """\xE5\xAD\x90"/*��*/"""\xE4\xBB\xBB"/*��*/"""\xE5\x8A\xA1"/*��*/"8.5", "",};
                                       
static const char *btnm_test_map9[] = {"""\xE5\xAD\x90"/*��*/"""\xE4\xBB\xBB"/*��*/"""\xE5\x8A\xA1"/*��*/"9.1", "\n",
                                       """\xE5\xAD\x90"/*��*/"""\xE4\xBB\xBB"/*��*/"""\xE5\x8A\xA1"/*��*/"9.2", "\n",
                                       """\xE5\xAD\x90"/*��*/"""\xE4\xBB\xBB"/*��*/"""\xE5\x8A\xA1"/*��*/"9.3", "\n",
                                       """\xE5\xAD\x90"/*��*/"""\xE4\xBB\xBB"/*��*/"""\xE5\x8A\xA1"/*��*/"9.4", "\n",
                                       """\xE5\xAD\x90"/*��*/"""\xE4\xBB\xBB"/*��*/"""\xE5\x8A\xA1"/*��*/"9.5", "",};
/*----------------------------------------------------------------------*/




void lv_mainstart(void);
void rt_thread_tast(void);
/* �������������� */
void create_main_btnmatrix(void);
/* �����Ӱ������� */
void create_test_btnmatrix(void);

#ifdef __cplusplus
}
#endif

#endif // _USER_APP_H

