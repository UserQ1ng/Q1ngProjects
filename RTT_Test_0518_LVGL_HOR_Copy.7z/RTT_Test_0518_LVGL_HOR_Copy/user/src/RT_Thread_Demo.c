/*
 * RT_Thread_Demo.c
 *
 * created: 2024/6/28
 *  author: 
 */

/* ������ */
static rt_thread_t p_lv_tick_thread = NULL;
static rt_thread_t m_lv_mainstart_thread = NULL;

/* ��ջ��С */
#define LVGL_TICK_STATCK_SIZE   (2*1024)*4
#define LVGL_TICK_PRIORITY      20




void rt_thread_start_task(void)
{
    /* LVGL���� */
    p_lv_tick_thread = rt_thread_create("lv_tick",
                                        lv_tick_thread,
                                        NULL,         // arg
                                        LVGL_TICK_STATCK_SIZE,   // TODO statck size
                                        LVGL_TICK_PRIORITY,           // TODO priority
                                        10);          // slice ticks
    if (p_lv_tick_thread == NULL)
    {
        rt_kprintf("create p_lv_tick_thread fail!\r\n");
        return -1;
    }
    else
    {
        rt_thread_startup(p_lv_tick_thread);
    }
    /* LVGL���� */
    m_lv_mainstart_thread = rt_thread_create("lv_mainstart_thread",
                                             lv_mainstart_thread,
                                             NULL,
                                             1024 * 4,
                                             22,
                                             10);
    if (m_lv_mainstart_thread == NULL)
    {
        rt_kprintf("create m_lv_mainstart_thread fail!\r\n");
    }
    else
    {
        rt_thread_startup(m_lv_mainstart_thread);
    }
}

/* �̴߳��� */
static void lv_mainstart_thread(void *arg)
{
    // unsigned int tickcount;
    lv_mainstart();
    for (;;)
    {
        lv_task_handler();
        rt_thread_delay(10);
    }
}




















static void lv_tick_thread(void *arg)
{
    /*
     * Add lv_tick initialize code here.//ִֻ��һ��
     */

    for ( ; ; )
    {
        /*
         * Add lv_tick task code here.
         */
        lv_tick_inc(10);//LVGL��������
        // ...

        /* abandon cpu time to run other task */
        rt_thread_delay(10);   // task sleep 10 ms

    }
}

int lv_tick_create(int startIt)
{
    

    return 0;
}
