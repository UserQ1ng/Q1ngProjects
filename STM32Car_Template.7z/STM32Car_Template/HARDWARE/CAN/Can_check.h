#ifndef __CAN_CHECK_H__
#define __CAN_CHECK_H__


void Can_check_Init(uint16_t arr,uint16_t psc);



#endif

